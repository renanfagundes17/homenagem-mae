
# Homenagem para a Mãe 💖

Este projeto é uma homenagem criada por **Renan Fagundes** para sua mãe. Ele apresenta uma linda animação com corações caindo e uma mensagem emocionante sobre amor e gratidão.

## 📸 Visual
![Preview](foto_mae.png)

## 🧑‍💻 Tecnologias utilizadas
- HTML5
- CSS3
- JavaScript

## 🌐 Como usar
Abra o arquivo `index.html` em qualquer navegador. Você pode também publicar usando GitHub Pages.

## ✨ Autor
**Renan Fagundes** - [GitHub](https://github.com/renanfagundes17)
